<?php include 'includes/connection.php';?>
<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>

<?php
session_start();
if (isset($_POST['login'])) {
  $email  = $_POST['email'];
  $password = $_POST['pass'];
  mysqli_real_escape_string($conn, $email);
  mysqli_real_escape_string($conn, $password);
$query = "SELECT * FROM users WHERE email = '$email'";
$result = mysqli_query($conn , $query) or die (mysqli_error($conn));
if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_array($result)) {
    $id = $row['id'];
    $name = $row['name'];
    $pass = $row['password'];
    $email = $row['email'];
    $phone_number = $row['phone_number'];
  
    if (password_verify($password, $pass )) {
      $_SESSION['id'] = $id;
      $_SESSION['name'] = $name;
      $_SESSION['email']  = $email;
      $_SESSION['phone_number'] = $phone_number;
   
      header('location: dashboard/');
    }
    else {
      echo "<script>alert('invalid email or password');
      window.location.href= 'index.php';</script>";

    }
  }
}
else {
      echo "<script>alert('invalid email or password');
      window.location.href= 'index.php';</script>";

    }
}
?>


  <div class="login-card">
    <h1>Log-in</h1><br>
  <form method="POST">
    <input type="text" name="email" placeholder="email" required="">
    <input type="password" name="pass" placeholder="Password" required="">
    <input type="submit" name="login" class="login login-submit" value="login">
  </form>
    
  <div class="login-help">
    <a href="signup.php">Register</a> • <a href="recoverpassword.php">   Forgot Password</a>
  </div>
</div>

  <script src='css/jquery.min.js'></script>
<script src='css/jquery-ui.min.js'></script>

  
</body>
</html>
