<?php include 'includes/connection.php';?>
<?php include 'includes/header.php';?>

<?php include 'includes/navbar.php';?>

<?php
if (isset($_POST['signup'])) {
require "gump.class.php";
$gump = new GUMP();
$_POST = $gump->sanitize($_POST); 

$gump->validation_rules(array(
  'name'        => 'required|alpha_space|max_len,60|min_len,3',
  'email'       => 'required|valid_email',
  'phone_number'    => 'required|alpha_numeric|max_len,20|min_len,4',
  'password'    => 'required|max_len,50|min_len,2',
));
$gump->filter_rules(array(
  'name'     => 'trim|sanitize_string',
  'password' => 'trim',
  'email'    => 'trim|sanitize_email',
  'phone_number' => 'trim|sanitize_string',
  ));
$validated_data = $gump->run($_POST);

if($validated_data === false) {
  ?>
  <center><font color="red" > <?php echo $gump->get_readable_errors(true); ?> </font></center>
  <?php
}
else if ($_POST['password'] !== $_POST['repassword']) 
{
  echo  "<center><font color='red'>Passwords do not match </font></center>";
}

$email = $validated_data['email'];
 // first check the database to make sure
    // a user does not already exist with the same email
    $user_check_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // if user exists
      if ($user['email'] === $email) {
        echo  "<center><font color='red'>email is already taken! try a different one</font></center>";
      }
    }

  else {
    $name = $validated_data['name'];
    $email = $validated_data['email'];
    $pass = $validated_data['password'];
    $password = password_hash("$pass" , PASSWORD_DEFAULT);
    $phone_number = $_POST['phone_number'];

    $query = "INSERT INTO users(name,email,phone_number,password) VALUES ('$name' , '$email', '$phone_number','$password')";
    $result = mysqli_query($conn , $query) or die(mysqli_error($conn));
    if (mysqli_affected_rows($conn) > 0) { 
      echo "<script>alert('SUCCESSFULLY REGISTERED');
      window.location.href='index.php';</script>";
}
else {
  echo "<script>alert('Error Occured');</script>";
}
}
}

?>
<br>

<div class="container">


      <div  class="form">
        <form id="contactform" method="POST"> 
          <p class="contact"><label for="name">Full Name / Company Name</label></p> 
          <input id="name" name="name" placeholder="Full Name / Company Name" required="" tabindex="1" type="text" value="<?php if(isset($_POST['signup'])) { echo $_POST['name']; } ?>"> 
           
          <p class="contact"><label for="email">Email / Company Email</label></p> 
          <input id="email" name="email" placeholder="example@domain.com" required="" type="email" value="<?php if(isset($_POST['signup'])) { echo $_POST['email']; } ?>"> 
         
          <p class="contact"><label for="phone_number">Phone Number</label></p> 
          <input id="phone_number" name="phone_number" placeholder="+234(000 000 00)" required="" type="text" value="<?php if(isset($_POST['signup'])) { echo $_POST['phone_number']; } ?>"> 
                
                <p class="contact"><label for="password">Create a password</label></p> 
          <input type="password" id="password" name="password" required=""> 
                <p class="contact"><label for="repassword">Confirm your password</label></p> 
          <input type="password" id="repassword" name="repassword" required=""> 
        
          
            
            <input class="buttom" name="signup" id="submit" tabindex="5" value="Sign me up!" type="submit">    
   </form> 
</div>      
</div>

</body>
</html>