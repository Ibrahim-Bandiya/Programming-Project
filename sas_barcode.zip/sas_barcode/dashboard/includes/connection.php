<?php
$conn = mysqli_connect("localhost","root","","sas_barcode" ) or die ("error" . mysqli_error($conn));
?>
