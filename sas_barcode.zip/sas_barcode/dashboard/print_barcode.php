<?php
include ('includes/connection.php');
include ('includes/adminheader.php');


?>
<?php
if (isset($_SESSION['id'])) {
    $uid = $_SESSION['id'];
    $print_id = mysqli_real_escape_string($conn, $_GET['print_id']);
	$query = "SELECT * FROM history WHERE id='$print_id' and uid = '$uid' " ; 
	$result= mysqli_query($conn , $query) or die (mysqli_error($conn));
	if (mysqli_num_rows($result) > 0 ) {
		$row = mysqli_fetch_array($result);
        $id = $row['id'];
       // $uid = $row['uid'];
		$product_name = $row['product_name'];
		$product_id = $row['product_id'];
		$price = $row['price'];
        $copies = $row['copies'];
		
	}

}
?>

<div id="wrapper">

        
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to your Profile 
                            <small><?php echo $_SESSION['name']; ?></small>
                        </h1>

    <form role="form" action="bar.php" method="POST" enctype="multipart/form-data">
    <hr>
    <div class="form-group">        
<div class="col-sm-offset-2 col-sm-10">
<button type="submit" style="margin-left:800px;" name="submit" class="btn btn-success">Print</button>
</div>
</div>
    <div class="container-fluid">

<div class="row">
    <div class="col-lg-12">
<form class="form-horizontal" method="post" action="bar.php" target="_blank">

<div class="form-group">
		<label for="user_author">Name</label>
		<input type="text" name="product_name" class="form-control"  value="<?php echo $product_name; ?>" readonly>
	</div>

	<div class="form-group">
		<label for="user_tag">product ID</label>
		<input type="email" name="product_id" class="form-control"  value="<?php echo $product_id; ?>" readonly>
	</div>
	
    <div class="form-group">
		<label for="user_title">price</label>
		<input type="text" name="price" class="form-control" value=" <?php echo $price; ?>" >
	</div> 
    <div class="form-group">
		<label for="user_title">copies</label>
		<input type="text" name="copies" class="form-control" value=" <?php echo $copies; ?>" >
	</div> 
                    </div>
                </div>
                

            </div>
<div class="col-sm-5">          
<input type="hidden" name="id" value=" <?php echo $row['id']; ?>">
<input type="hidden" name="uid" value=" <?php echo $_SESSION['id']; ?>">
</div>

</form>
</div>
</div>
<?php include ('includes/footer.php'); ?>
<script src="js/jquery.js"></script>
	
    <script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
