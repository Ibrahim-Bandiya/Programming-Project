<?php include 'includes/connection.php'; ?>

<?php include 'includes/adminheader.php'; ?>

<div id="wrapper">
       
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">
     <div class="container-fluid">

         <!-- Page Heading -->
         <div class="row">
             <div class="col-lg-12">
                 <h1 class="page-header">
                 <div class="col-xs-4">
     <a href="index.php" class="btn btn-primary">Generate New Barcode</a>
     </div>
                  MY Barcode(s)
                 </h1>
        <div class="card-body">
            <div class="container-flui">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="bg-gradient bg-primary text-light">
                            <th>S/N</th>
                            <th>Product Name </th>
                        <th>Product ID</th>
                        <th>price</th>
                        <th>Copy(ies)</th>
                        <th>generated on</th>
                        <th>print</th>
                        <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $uid = $_SESSION['id'];
                       
                            $history = $conn->query("SELECT * FROM `history` WHERE uid= '$uid' order by unix_timestamp(date_created) desc"); 
                            $i = 1;
                            while($row = $history->fetch_array()):
                                $id = $row['id'];
                        ?>
                        <tr>
                            <td class="px-2 py-1"><?= $i++; ?></td>
                            <td class="px-2 py-1"><?= $row['product_name'] ?></td>
                            <td class="px-2 py-1"><?= $row['product_id'] ?></td>
                            <td class="px-2 py-1"><?= $row['price'] ?></td>
                            <td class="px-2 py-1"><?= $row['copies'] ?></td>
                            <td class="px-2 py-1"><?= date("Y-m-d H:i",strtotime($row['date_created'])) ?></td>
                            <td class="px-2 py-1"><a href="print_barcode.php?print_id=<?php echo $row["id"]; ?>"
                     type="submit" name="submit" class="btn btn-success"> Print</a></td>
                            <td class="px-2 py-1"> <a href="delete_history.php?del_id=<?php echo $row["id"]; ?>"
                     type="submit"  class="btn btn-danger"> Delete</a></td>
                            
                        </tr>
                        <?php endwhile; ?>

                    </tbody>
                </table>
            </div>
        </div>
       
    </div>
</div>


<?php include ('includes/footer.php'); ?>
<script src="js/jquery.js"></script>

  
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
