<?php include ('includes/connection.php'); 

?>
<?php include('includes/adminheader.php');  ?>


 <div id="wrapper">
       
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        &nbsp; Welcome 
                            <small><?php echo $_SESSION['name']; ?></small>
                        </h1>


 <h3 >
                            <center> <marquee width = 100% ><font color="green" >WELCOME TO SAS FREE BARCODE GENERATOR</marquee></center>
                        </h3>

  <hr>
  <h4 >
                            <center>fill in the form to generate your Barcode</center>
                        </h4>
                       
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-12">
  	<form class="form-horizontal" method="post" action="barcode.php" target="_blank">
  	<div class="form-group">
      <label class="control-label col-sm-2" for="product">Product Name:</label>
      <div class="col-sm-5">
        <input autocomplete="OFF" type="text" class="form-control" id="product" name="product_name" required="">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="product_id">Product ID:</label>
      <div class="col-sm-5">
        <input autocomplete="OFF" type="text" class="form-control" id="product_id" name="product_id" required="">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="rate">Price</label>
      <div class="col-sm-5">          
        <input autocomplete="OFF" type="text" class="form-control" id="rate"  name="price" required="">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="print_qty">Barcode Quantity</label>
      <div class="col-sm-5">          
        <input autocomplete="OFF" type="print_qty" class="form-control" id="print_qty"  name="copies" required="">
      </div>
    </div>
    <div class="col-sm-5">          
    <input type="hidden" name="uid" value=" <?php echo $_SESSION['id']; ?>">
      </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
  </div>
    </div>
  <?php include ('includes/footer.php'); ?>
<script src="js/jquery.js"></script>

  
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
