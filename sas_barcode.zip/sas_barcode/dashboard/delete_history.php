<?php
error_reporting(0);
include 'includes/connection.php'; 
if(isset($_GET['del_id'])){
  
$delete = $conn->query("DELETE FROM `history` where id ='".$_GET['del_id']."'");
if($delete){
  echo "<script>alert('Delete successful!'); window.location.href='barcodehistory.php';</script>";

   
}
else{
  echo "<script>alert('undefined ID'); window.location.href='index.php';</script>";
$conn->close();
exit;
}
}
?>