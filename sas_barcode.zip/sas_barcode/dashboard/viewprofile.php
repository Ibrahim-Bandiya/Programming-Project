<?php
include ('includes/connection.php');
include ('includes/adminheader.php');


?>
<?php
if (isset($_SESSION['id'])) {
	$id = $_SESSION['id'];
	$query = "SELECT * FROM users WHERE id = '$id'" ; 
	$result= mysqli_query($conn , $query) or die (mysqli_error($conn));
	if (mysqli_num_rows($result) > 0 ) {
		$row = mysqli_fetch_array($result);
		$userid = $row['id'];
		$name = $row['name'];
		$email = $row['email'];
		$phone_number = $row['phone_number'];
		
	}



}
?>


<div id="wrapper">

        
       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to your Profile 
                            <small><?php echo $_SESSION['name']; ?></small>
                        </h1>
<form role="form" action="" method="POST" enctype="multipart/form-data">


    </form>


    <form role="form" action="" method="POST" enctype="multipart/form-data">
    <hr>





	<div class="form-group">
		<label for="user_author">Name</label>
		<input type="text" name="name" class="form-control"  value="<?php echo $name; ?>" readonly>
	</div>

	<div class="form-group">
		<label for="user_tag">Email</label>
		<input type="email" name="email" class="form-control"  value="<?php echo $email; ?>" readonly>
	</div>
	
<div class="form-group">
		<label for="user_title">Phone Number</label>
		<input type="text" name="phone_number" class="form-control" value=" <?php echo $phone_number; ?>" readonly>
	</div> 

                    </div>
                </div>
                

            </div>
            

    </div>
    <?php include ('includes/footer.php'); ?>
<script src="js/jquery.js"></script>

  
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
